package com.example.willisproject2cs360;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    Button signInButton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        signInButton = findViewById(R.id.SignInButton);
        setupListeners();
    }

    private void setupListeners(){
        signInButton.setOnClickListener(new View.OnClickListener(){
           @Override
           public void onClick(View v) {
               Intent changeScreen = new Intent(v.getContext(), WeightClass.class);
               startActivityForResult(changeScreen, 0);
           }
        });
    }
}