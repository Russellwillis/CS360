package com.example.willisproject2cs360;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Currency;

public class WeightClass extends AppCompatActivity {
    Button settings, addButton, deleteButton, weightGoalButton;
    LinearLayout layout;
    RecyclerView recyclerView;
    CustomAdapter customAdapter;
    weightsDB db;
    ArrayList<String> weightsID, weights;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_class);

        recyclerView = findViewById(R.id.rv);
        settings = findViewById(R.id.settings);
        addButton = findViewById(R.id.add);
        deleteButton = findViewById(R.id.delete);
        weightGoalButton = findViewById(R.id.WeightGoalButton);
        db = new weightsDB(WeightClass.this);
        weightsID = new ArrayList<>();
        weights = new ArrayList<>();

        displayData();
        customAdapter = new CustomAdapter(WeightClass.this,weightsID,weights );
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(WeightClass.this));

        settings.setOnClickListener(view -> {
            Intent settings = new Intent(this, permissions.class);
            startActivity(settings);
        });
        addButton.setOnClickListener(view -> {
            Intent add = new Intent(this, AddweightsActivity.class);
            startActivity(add);
        });

    }

    void displayData(){
        Cursor cursor = db.ReadAllData();
        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Data", Toast.LENGTH_SHORT).show();
        }
        else{
            while(cursor.moveToNext()){
                weightsID.add(cursor.getString(0));
                weights.add(cursor.getString(1));
            }
        }
    }
}
