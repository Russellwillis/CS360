package com.example.willisproject2cs360;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.atomic.AtomicReference;


public class AddweightsActivity extends AppCompatActivity {

    Button addWeight, back;
    EditText add;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addweights);

        addWeight = findViewById(R.id.AddWeight);
        back = findViewById(R.id.BackToMain);
        add = findViewById(R.id.addWeight);

        addWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                weightsDB db = new weightsDB(AddweightsActivity.this);
                db.addWeight(add.getText().toString().trim());
                Intent changeScreen = new Intent(v.getContext(), WeightClass.class);
                startActivity(changeScreen);
            }
        });
    }







}