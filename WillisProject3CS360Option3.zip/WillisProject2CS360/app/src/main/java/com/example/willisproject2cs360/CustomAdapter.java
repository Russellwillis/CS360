package com.example.willisproject2cs360;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.MenuView;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {
    Context context;
    ArrayList weightID, weights;
    CustomAdapter(Context context, ArrayList weightID, ArrayList weights){
        this.context = context;
        this.weightID = weightID;
        this.weights = weights;


    }
    @NonNull
    @Override
    public CustomAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter.MyViewHolder holder, int position) {
        holder.weightID.setText(String.valueOf(weightID.get(position)));
        holder.weights.setText(String.valueOf(weights.get(position)));
    }

    @Override
    public int getItemCount() {
        return weightID.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

         TextView weightID, weights;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            weightID = itemView.findViewById(R.id.WeightIdText);
            weights = itemView.findViewById(R.id.WeightText);
        }
    }
}
