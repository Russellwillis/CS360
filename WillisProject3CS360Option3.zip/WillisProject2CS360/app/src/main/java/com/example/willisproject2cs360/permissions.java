package com.example.willisproject2cs360;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class permissions extends AppCompatActivity {
    Button Back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permissions);
        Back = findViewById(R.id.Back);
        setupListeners();
    }

    private void setupListeners(){
        Back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent changeScreen = new Intent(v.getContext(), WeightClass.class);
                startActivityForResult(changeScreen, 0);
            }
        });
    }
}